package com.notetime.model;

/**
 * Collaboration:
 * Sean Nyakutira | +260968597996 | SEANTINASHENYAKUTIRA@gmail.com
 * Zvikomborero Svotwa | +260973439282 | zvikomborerosvotwa28@gmail.com
 */

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class Note {
    private final String id;
    private String title;
    private String body;
    private LocalDateTime lastUpdated;
    private final List<Attachment> attachments;

    public Note() {
        this(UUID.randomUUID().toString(), "Untitled note", "", LocalDateTime.now(), new ArrayList<>());
    }

    public Note(String id, String title, String body, LocalDateTime lastUpdated, List<Attachment> attachments) {
        this.id = id;
        this.title = title;
        this.body = body;
        this.lastUpdated = lastUpdated;
        this.attachments = attachments != null ? new ArrayList<>(attachments) : new ArrayList<>();
    }

    public String getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getBody() {
        return body;
    }

    public void setBody(String body) {
        this.body = body;
    }

    public LocalDateTime getLastUpdated() {
        return lastUpdated;
    }

    public void setLastUpdated(LocalDateTime lastUpdated) {
        this.lastUpdated = lastUpdated;
    }

    public List<Attachment> getAttachments() {
        return attachments;
    }

    public void replaceAttachments(List<Attachment> newAttachments) {
        attachments.clear();
        attachments.addAll(newAttachments);
    }
}


