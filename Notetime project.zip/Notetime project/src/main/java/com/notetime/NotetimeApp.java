package com.notetime;

/**
 * Collaboration:
 * Sean Nyakutira | +260968597996 | SEANTINASHENYAKUTIRA@gmail.com
 * Zvikomborero Svotwa | +260973439282 | zvikomborerosvotwa28@gmail.com
 */

import com.notetime.model.Attachment;
import com.notetime.model.AttachmentType;
import com.notetime.model.Note;
import com.notetime.storage.NotesRepository;
import com.notetime.ui.MotionBackground;
import com.notetime.ui.NoteCell;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.awt.Desktop;
import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

public class NotetimeApp extends Application {
    private static final DateTimeFormatter CLOCK_FORMATTER = DateTimeFormatter.ofPattern("EEE, MMM d • hh:mm a");
    private static final Color DEFAULT_ACCENT = Color.web("#3D8BFD");
    private final Path baseDir = Paths.get("").toAbsolutePath();
    private final NotesRepository repository = new NotesRepository(baseDir.resolve("data"));
    private final ObservableList<Note> notes = FXCollections.observableArrayList();
    private final ObservableList<Attachment> editingAttachments = FXCollections.observableArrayList();

    private BorderPane root;
    private ListView<Note> notesListView;
    private TextField titleField;
    private TextArea bodyArea;
    private FlowPane attachmentsPane;
    private Label emptyStateLabel;
    private Label clockLabel;
    private ToggleButton themeToggle;
    private ColorPicker accentPicker;
    private Timeline clockTimeline;

    private Note activeNote;

    @Override
    public void start(Stage stage) {
        Font.loadFont(Objects.requireNonNull(getClass().getResource("/fonts/Montserrat-Regular.ttf")).toExternalForm(), 14);
        notes.setAll(repository.loadNotes());
        buildStage(stage);
        startClock();
        applyTheme(false);
        applyAccent(DEFAULT_ACCENT);
        if (!notes.isEmpty()) {
            notesListView.getSelectionModel().selectFirst();
        } else {
            createNewNote();
        }
    }

    private void buildStage(Stage stage) {
        root = new BorderPane();
        root.getStyleClass().add("app-root");

        MotionBackground hero = new MotionBackground();
        VBox heroContent = new VBox(
                new Label("Notetime"),
                new Label("Capture ideas with motion, color, and sound"));
        heroContent.getStyleClass().add("hero-copy");
        heroContent.setAlignment(Pos.CENTER_LEFT);
        heroContent.setSpacing(6);
        heroContent.setPadding(new Insets(24, 32, 24, 32));

        StackPane heroWrapper = new StackPane(hero, heroContent);
        heroWrapper.getStyleClass().add("hero");
        VBox top = new VBox(buildTopBar(), heroWrapper);
        top.getStyleClass().add("hero-wrapper");
        root.setTop(top);

        notesListView = new ListView<>(notes);
        notesListView.setCellFactory(list -> new NoteCell());
        notesListView.getSelectionModel().selectedItemProperty().addListener((obs, old, selected) -> {
            if (selected != null) {
                loadNote(selected);
            }
        });

        VBox leftPanel = new VBox();
        leftPanel.getStyleClass().add("left-panel");
        leftPanel.setSpacing(16);
        leftPanel.setPadding(new Insets(16));
        leftPanel.getChildren().add(buildSidebarControls());
        VBox.setVgrow(notesListView, Priority.ALWAYS);
        leftPanel.getChildren().add(notesListView);
        leftPanel.setPrefWidth(320);
        root.setLeft(leftPanel);

        VBox editor = buildEditor();
        root.setCenter(editor);

        Scene scene = new Scene(root, 1200, 720);
        scene.getStylesheets().add(
                Objects.requireNonNull(getClass().getResource("/styles/app.css")).toExternalForm());
        stage.setTitle("Notetime");
        stage.setScene(scene);
        stage.setOnCloseRequest(event -> repository.saveNotes(new ArrayList<>(notes)));
        stage.show();
    }

    private HBox buildSidebarControls() {
        Button newNoteBtn = new Button("New note");
        newNoteBtn.getStyleClass().add("primary");
        newNoteBtn.setOnAction(e -> createNewNote());

        Button openTextBtn = new Button("Open text file");
        openTextBtn.setOnAction(e -> importTextFile());

        HBox controls = new HBox(newNoteBtn, openTextBtn);
        controls.setSpacing(12);
        controls.setPadding(new Insets(12));
        controls.getStyleClass().add("sidebar-controls");
        return controls;
    }

    private HBox buildTopBar() {
        Label brand = new Label("Notetime");
        brand.getStyleClass().add("brand-mark");

        clockLabel = new Label();
        clockLabel.getStyleClass().add("clock-display");

        themeToggle = new ToggleButton("Dark");
        themeToggle.getStyleClass().add("theme-toggle");
        themeToggle.selectedProperty().addListener((obs, old, isDark) -> {
            applyTheme(isDark);
            themeToggle.setText(isDark ? "Light" : "Dark");
        });

        accentPicker = new ColorPicker(DEFAULT_ACCENT);
        accentPicker.getStyleClass().add("accent-picker");
        accentPicker.valueProperty().addListener((obs, old, color) -> applyAccent(color));

        Label paletteLabel = new Label("Accent");
        paletteLabel.getStyleClass().add("palette-label");

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        HBox bar = new HBox(brand, clockLabel, spacer, themeToggle, paletteLabel, accentPicker);
        bar.getStyleClass().add("top-bar");
        bar.setAlignment(Pos.CENTER_LEFT);
        bar.setSpacing(16);
        return bar;
    }

    private VBox buildEditor() {
        titleField = new TextField();
        titleField.setPromptText("Note title");

        bodyArea = new TextArea();
        bodyArea.setWrapText(true);
        bodyArea.setPromptText("Write your thoughts here...");

        attachmentsPane = new FlowPane();
        attachmentsPane.setHgap(8);
        attachmentsPane.setVgap(8);
        attachmentsPane.getStyleClass().add("attachments-pane");

        emptyStateLabel = new Label("Select a note from the left or create a new one.");
        emptyStateLabel.getStyleClass().add("empty-state");

        Button saveBtn = new Button("Save changes");
        saveBtn.getStyleClass().add("primary");
        saveBtn.setOnAction(e -> saveActiveNote());

        Button insertTableBtn = new Button("Insert table");
        insertTableBtn.getStyleClass().add("ghost");
        insertTableBtn.setOnAction(e -> promptInsertTable());

        Button deleteBtn = new Button("Delete");
        deleteBtn.getStyleClass().add("ghost");
        deleteBtn.setOnAction(e -> deleteActiveNote());

        Button imageBtn = new Button("Add picture");
        imageBtn.setOnAction(e -> addAttachment(AttachmentType.IMAGE, List.of("*.png", "*.jpg", "*.jpeg", "*.gif")));

        Button audioBtn = new Button("Add audio");
        audioBtn.setOnAction(e -> addAttachment(AttachmentType.AUDIO, List.of("*.mp3", "*.wav", "*.aac", "*.m4a")));

        Button fileBtn = new Button("Add file");
        fileBtn.setOnAction(e -> addAttachment(AttachmentType.DOCUMENT, List.of("*.*")));

        HBox actionRow = new HBox(imageBtn, audioBtn, fileBtn, insertTableBtn, new Region(), deleteBtn, saveBtn);
        Region spacer = (Region) actionRow.getChildren().get(4);
        HBox.setHgrow(spacer, Priority.ALWAYS);
        actionRow.setSpacing(12);

        VBox editorBox = new VBox(
                emptyStateLabel,
                titleField,
                bodyArea,
                new Label("Attachments"),
                attachmentsPane,
                actionRow
        );
        editorBox.setSpacing(12);
        editorBox.setPadding(new Insets(24));
        editorBox.getStyleClass().add("editor");
        VBox.setVgrow(bodyArea, Priority.ALWAYS);
        return editorBox;
    }

    private void createNewNote() {
        Note note = new Note();
        note.setLastUpdated(LocalDateTime.now());
        notes.add(0, note);
        notesListView.getSelectionModel().select(note);
    }

    private void loadNote(Note note) {
        activeNote = note;
        titleField.setText(note.getTitle());
        bodyArea.setText(note.getBody());
        editingAttachments.setAll(note.getAttachments());
        emptyStateLabel.setVisible(false);
        refreshAttachments();
    }

    private void saveActiveNote() {
        if (activeNote == null) {
            return;
        }
        activeNote.setTitle(titleField.getText().isBlank() ? "Untitled note" : titleField.getText());
        activeNote.setBody(bodyArea.getText());
        activeNote.setLastUpdated(LocalDateTime.now());
        activeNote.replaceAttachments(new ArrayList<>(editingAttachments));
        notesListView.refresh();
        repository.saveNotes(new ArrayList<>(notes));
    }

    private void deleteActiveNote() {
        if (activeNote == null) {
            return;
        }
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Delete note");
        alert.setHeaderText("Delete this note?");
        alert.setContentText("This action cannot be undone.");
        Optional<ButtonType> result = alert.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            notes.remove(activeNote);
            repository.saveNotes(new ArrayList<>(notes));
            if (!notes.isEmpty()) {
                notesListView.getSelectionModel().selectFirst();
            } else {
                activeNote = null;
                titleField.clear();
                bodyArea.clear();
                editingAttachments.clear();
                refreshAttachments();
                emptyStateLabel.setVisible(true);
            }
        }
    }

    private void addAttachment(AttachmentType type, List<String> extensions) {
        FileChooser chooser = new FileChooser();
        chooser.setTitle("Select " + type.getLabel());
        chooser.getExtensionFilters().add(new FileChooser.ExtensionFilter(type.getLabel(), extensions));
        File file = chooser.showOpenDialog(titleField.getScene().getWindow());
        if (file == null) {
            return;
        }
        try {
            Attachment attachment = repository.createAttachment(file.toPath(), type, baseDir);
            editingAttachments.add(attachment);
            refreshAttachments();
        } catch (IOException e) {
            showError("Upload failed", "Could not copy the selected file.");
        }
    }

    private void refreshAttachments() {
        attachmentsPane.getChildren().clear();
        if (editingAttachments.isEmpty()) {
            attachmentsPane.getChildren().add(new Label("No attachments yet."));
            return;
        }
        for (Attachment attachment : editingAttachments) {
            HBox chip = new HBox();
            chip.getStyleClass().add("attachment-chip");
            Label name = new Label(attachment.getFileName());
            Button open = new Button("Open");
            open.setOnAction(e -> openFile(attachment.getAbsolutePath()));
            Button remove = new Button("Remove");
            remove.getStyleClass().add("ghost");
            remove.setOnAction(e -> {
                editingAttachments.remove(attachment);
                refreshAttachments();
            });
            chip.getChildren().addAll(name, new Region(), open, remove);
            Region spacer = (Region) chip.getChildren().get(1);
            HBox.setHgrow(spacer, Priority.ALWAYS);
            chip.setSpacing(8);
            chip.setAlignment(Pos.CENTER_LEFT);
            attachmentsPane.getChildren().add(chip);
        }
    }

    private void openFile(String absolutePath) {
        if (!Desktop.isDesktopSupported()) {
            showError("Not supported", "Desktop operations are not supported on this system.");
            return;
        }
        try {
            Desktop.getDesktop().open(new File(absolutePath));
        } catch (IOException e) {
            showError("Unable to open", "Could not open the attachment.");
        }
    }

    private void importTextFile() {
        FileChooser chooser = new FileChooser();
        chooser.setTitle("Open text document");
        chooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("Text & Markdown", "*.txt", "*.md", "*.markdown"),
                new FileChooser.ExtensionFilter("Rich text", "*.rtf"),
                new FileChooser.ExtensionFilter("CSV & JSON", "*.csv", "*.json"),
                new FileChooser.ExtensionFilter("All files", "*.*")
        );
        File file = chooser.showOpenDialog(bodyArea.getScene().getWindow());
        if (file == null) {
            return;
        }
        try {
            String content = Files.readString(file.toPath(), StandardCharsets.UTF_8);
            bodyArea.setText(content);
            if (titleField.getText().isBlank()) {
                titleField.setText(file.getName());
            }
        } catch (IOException e) {
            showError("Read error", "Unable to open the selected document.");
        }
    }

    private void showError(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void promptInsertTable() {
        Dialog<ButtonType> dialog = new Dialog<>();
        dialog.setTitle("Insert table");
        dialog.setHeaderText("Structure content with a quick table");
        dialog.getDialogPane().getButtonTypes().addAll(ButtonType.CANCEL, ButtonType.OK);

        Spinner<Integer> rowsSpinner = new Spinner<>(1, 12, 2);
        Spinner<Integer> colsSpinner = new Spinner<>(1, 6, 3);
        rowsSpinner.setEditable(true);
        colsSpinner.setEditable(true);

        GridPane content = new GridPane();
        content.setHgap(12);
        content.setVgap(12);
        content.addRow(0, new Label("Rows"), rowsSpinner);
        content.addRow(1, new Label("Columns"), colsSpinner);
        dialog.getDialogPane().setContent(content);

        dialog.showAndWait().filter(button -> button == ButtonType.OK)
                .ifPresent(button -> insertTable(rowsSpinner.getValue(), colsSpinner.getValue()));
    }

    private void insertTable(int rows, int columns) {
        StringBuilder builder = new StringBuilder("\n|");
        for (int col = 1; col <= columns; col++) {
            builder.append(" Header ").append(col).append(" |");
        }
        builder.append("\n|");
        for (int col = 0; col < columns; col++) {
            builder.append(" --- |");
        }
        for (int row = 1; row <= rows; row++) {
            builder.append("\n|");
            for (int col = 1; col <= columns; col++) {
                builder.append(" Cell ").append(row).append('.').append(col).append(" |");
            }
        }
        builder.append("\n");
        int caret = bodyArea.getCaretPosition();
        bodyArea.insertText(caret, builder.toString());
    }

    private void startClock() {
        if (clockTimeline != null) {
            clockTimeline.stop();
        }
        clockTimeline = new Timeline(new KeyFrame(Duration.seconds(1), event -> updateClock()));
        clockTimeline.setCycleCount(Timeline.INDEFINITE);
        clockTimeline.playFromStart();
        updateClock();
    }

    private void updateClock() {
        if (clockLabel != null) {
            clockLabel.setText(LocalDateTime.now().format(CLOCK_FORMATTER));
        }
    }

    private void applyTheme(boolean dark) {
        root.getStyleClass().removeAll("light-theme", "dark-theme");
        root.getStyleClass().add(dark ? "dark-theme" : "light-theme");
    }

    private void applyAccent(Color color) {
        String hex = toHex(color);
        String soft = toRgba(color, 0.18);
        root.setStyle(String.format("-color-accent: %s; -color-accent-soft: %s;", hex, soft));
    }

    private String toHex(Color color) {
        int r = (int) Math.round(color.getRed() * 255);
        int g = (int) Math.round(color.getGreen() * 255);
        int b = (int) Math.round(color.getBlue() * 255);
        return String.format("#%02X%02X%02X", r, g, b);
    }

    private String toRgba(Color color, double opacity) {
        int r = (int) Math.round(color.getRed() * 255);
        int g = (int) Math.round(color.getGreen() * 255);
        int b = (int) Math.round(color.getBlue() * 255);
        return String.format("rgba(%d, %d, %d, %.2f)", r, g, b, opacity);
    }

    @Override
    public void stop() {
        if (clockTimeline != null) {
            clockTimeline.stop();
        }
    }

    public static void main(String[] args) {
        launch();
    }
}


