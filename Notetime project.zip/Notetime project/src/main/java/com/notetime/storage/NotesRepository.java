package com.notetime.storage;

/**
 * Collaboration:
 * Sean Nyakutira | +260968597996 | SEANTINASHENYAKUTIRA@gmail.com
 * Zvikomborero Svotwa | +260973439282 | zvikomborerosvotwa28@gmail.com
 */

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.notetime.model.Attachment;
import com.notetime.model.AttachmentType;
import com.notetime.model.Note;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.lang.reflect.Type;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class NotesRepository {
    private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ISO_LOCAL_DATE_TIME;
    private final Path notesFile;
    private final Gson gson;

    public NotesRepository(Path dataDirectory) {
        try {
            Files.createDirectories(dataDirectory);
        } catch (IOException e) {
            throw new IllegalStateException("Unable to create data directory", e);
        }
        this.notesFile = dataDirectory.resolve("notes.json");
        GsonBuilder builder = new GsonBuilder();
        builder.registerTypeAdapter(LocalDateTime.class,
                (com.google.gson.JsonDeserializer<LocalDateTime>) (json, typeOfT, context) -> LocalDateTime.parse(json.getAsString(), DATE_FORMATTER));
        builder.registerTypeAdapter(LocalDateTime.class,
                (com.google.gson.JsonSerializer<LocalDateTime>) (src, typeOfSrc, context) -> context.serialize(src.format(DATE_FORMATTER)));
        builder.registerTypeAdapter(AttachmentType.class,
                (com.google.gson.JsonDeserializer<AttachmentType>) (json, typeOfT, context) -> AttachmentType.valueOf(json.getAsString()));
        builder.registerTypeAdapter(AttachmentType.class,
                (com.google.gson.JsonSerializer<AttachmentType>) (src, typeOfSrc, context) -> context.serialize(src.name()));
        this.gson = builder.setPrettyPrinting().create();
    }

    public List<Note> loadNotes() {
        if (!Files.exists(notesFile)) {
            return new ArrayList<>();
        }
        try (Reader reader = Files.newBufferedReader(notesFile)) {
            Type listType = new TypeToken<ArrayList<Note>>() {}.getType();
            List<Note> notes = gson.fromJson(reader, listType);
            return notes != null ? notes : new ArrayList<>();
        } catch (IOException e) {
            return new ArrayList<>();
        }
    }

    public void saveNotes(List<Note> notes) {
        try (Writer writer = Files.newBufferedWriter(notesFile)) {
            gson.toJson(notes, writer);
        } catch (IOException e) {
            throw new IllegalStateException("Unable to save notes", e);
        }
    }

    public Path getAssetsDirectory(Path baseDir) {
        try {
            Path assetsDir = baseDir.resolve("data").resolve("assets");
            Files.createDirectories(assetsDir);
            return assetsDir;
        } catch (IOException e) {
            throw new IllegalStateException("Unable to prepare assets directory", e);
        }
    }

    public Attachment createAttachment(Path sourceFile, AttachmentType type, Path baseDir) throws IOException {
        Path assetsDir = getAssetsDirectory(baseDir);
        Path target = assetsDir.resolve(sourceFile.getFileName());
        Path uniqueTarget = target;
        int counter = 1;
        while (Files.exists(uniqueTarget)) {
            String fileName = sourceFile.getFileName().toString();
            int dot = fileName.lastIndexOf('.');
            String name = dot > 0 ? fileName.substring(0, dot) : fileName;
            String ext = dot > 0 ? fileName.substring(dot) : "";
            uniqueTarget = assetsDir.resolve(name + "-" + counter + ext);
            counter++;
        }
        Files.copy(sourceFile, uniqueTarget);
        return new Attachment(uniqueTarget.getFileName().toString(), uniqueTarget.toAbsolutePath(), type);
    }
}


