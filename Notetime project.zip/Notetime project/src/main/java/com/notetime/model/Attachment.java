package com.notetime.model;

/**
 * Collaboration:
 * Sean Nyakutira | +260968597996 | SEANTINASHENYAKUTIRA@gmail.com
 * Zvikomborero Svotwa | +260973439282 | zvikomborerosvotwa28@gmail.com
 */

import java.nio.file.Path;
import java.util.Objects;
import java.util.UUID;

public class Attachment {
    private final String id;
    private final String fileName;
    private final String absolutePath;
    private final AttachmentType type;

    public Attachment(String fileName, Path absolutePath, AttachmentType type) {
        this(UUID.randomUUID().toString(), fileName, absolutePath.toString(), type);
    }

    public Attachment(String id, String fileName, String absolutePath, AttachmentType type) {
        this.id = id;
        this.fileName = fileName;
        this.absolutePath = absolutePath;
        this.type = type;
    }

    public String getId() {
        return id;
    }

    public String getFileName() {
        return fileName;
    }

    public String getAbsolutePath() {
        return absolutePath;
    }

    public AttachmentType getType() {
        return type;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Attachment that = (Attachment) o;
        return Objects.equals(id, that.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}


