package com.notetime.ui;

/**
 * Collaboration:
 * Sean Nyakutira | +260968597996 | SEANTINASHENYAKUTIRA@gmail.com
 * Zvikomborero Svotwa | +260973439282 | zvikomborerosvotwa28@gmail.com
 */

import com.notetime.model.Note;
import javafx.geometry.Insets;
import javafx.scene.control.Label;
import javafx.scene.control.ListCell;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;

import java.time.format.DateTimeFormatter;

public class NoteCell extends ListCell<Note> {
    private static final DateTimeFormatter CELL_FORMATTER = DateTimeFormatter.ofPattern("MMM d • hh:mm a");

    private final Label titleLabel = new Label();
    private final Text preview = new Text();
    private final Label timestamp = new Label();

    public NoteCell() {
        getStyleClass().add("note-cell");
        VBox textBox = new VBox(titleLabel, preview);
        textBox.setSpacing(4);
        HBox container = new HBox(textBox, timestamp);
        container.setSpacing(12);
        HBox.setHgrow(textBox, Priority.ALWAYS);
        preview.getStyleClass().add("note-preview");
        titleLabel.getStyleClass().add("note-title");
        timestamp.getStyleClass().add("note-timestamp");
        container.setPadding(new Insets(12));
        setGraphic(container);
    }

    @Override
    protected void updateItem(Note note, boolean empty) {
        super.updateItem(note, empty);
        if (empty || note == null) {
            setGraphic(null);
        } else {
            titleLabel.setText(note.getTitle());
            String body = note.getBody();
            preview.setText(body.length() > 50 ? body.substring(0, 50) + "…" : body);
            timestamp.setText(note.getLastUpdated().format(CELL_FORMATTER));
            setGraphic(getGraphic());
        }
    }
}


