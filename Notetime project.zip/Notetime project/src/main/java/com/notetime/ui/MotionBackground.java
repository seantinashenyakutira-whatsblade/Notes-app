package com.notetime.ui;

/**
 * Collaboration:
 * Sean Nyakutira | +260968597996 | SEANTINASHENYAKUTIRA@gmail.com
 * Zvikomborero Svotwa | +260973439282 | zvikomborerosvotwa28@gmail.com
 */

import javafx.animation.Animation;
import javafx.animation.Interpolator;
import javafx.animation.TranslateTransition;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.util.Duration;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class MotionBackground extends Pane {
    private final List<Animation> animations = new ArrayList<>();

    public MotionBackground() {
        setPrefHeight(180);
        setMinHeight(140);
        setMaxHeight(220);
        setStyle("-fx-background-color: linear-gradient(to right, #04366b, #0f5ea8);");
        createOrbs();
    }

    private void createOrbs() {
        Random random = new Random();
        for (int i = 0; i < 6; i++) {
            Circle orb = new Circle(60 + random.nextInt(40));
            orb.setOpacity(0.18);
            orb.setFill(i % 2 == 0 ? Color.web("#ffcf33") : Color.web("#ffc857"));
            orb.setCenterX(50 + i * 120.0);
            orb.setCenterY(80 + random.nextInt(40));
            getChildren().add(orb);

            TranslateTransition transition = new TranslateTransition(Duration.seconds(6 + random.nextInt(5)), orb);
            transition.setFromX(-20);
            transition.setToX(40);
            transition.setAutoReverse(true);
            transition.setCycleCount(Animation.INDEFINITE);
            transition.setInterpolator(Interpolator.EASE_BOTH);
            transition.play();
            animations.add(transition);
        }
    }

    public void stopAnimations() {
        animations.forEach(Animation::stop);
    }
}


